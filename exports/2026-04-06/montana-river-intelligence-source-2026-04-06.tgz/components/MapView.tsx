"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import mapboxgl from "mapbox-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import type { FishabilityRow, BiteTier } from "@/lib/types";
import { RIVER_FOCUS_POINTS } from "@/lib/river-focus-points";
import { MRI_COLORS } from "@/lib/theme";
import { createDefaultLayerState, type BasemapId, type LayerId } from "@/src/map/layers/registry";
import { MapControls } from "./MapControls";

const MONTANA_CENTER: [number, number] = [-109.75, 47.05];
const MONTANA_BOUNDS: [[number, number], [number, number]] = [
  [-116.15, 44.25],
  [-103.85, 49.2],
];
const DEFAULT_ZOOM = 6.15;
const FLY_ZOOM = 9.5;
const FLY_DURATION = 300;
const FLY_CURVE = 1.5;

const BITE_TIER_COLORS: Record<BiteTier, string> = {
  HOT: MRI_COLORS.warning,
  GOOD: MRI_COLORS.good,
  FAIR: MRI_COLORS.fair,
  TOUGH: MRI_COLORS.tough,
};

interface MapViewProps {
  rivers: FishabilityRow[];
  selectedRiver: FishabilityRow | null;
  selectedRiverName?: string | null;
  selectedRiverId: string | null;
  selectedRiverGeojson: GeoJSON.GeoJSON | null;
  riverLinesGeojson?: GeoJSON.FeatureCollection | null;
  activeStationsGeojson?: GeoJSON.FeatureCollection<GeoJSON.Point, Record<string, unknown>> | null;
  basemap?: BasemapId;
  layerState?: Record<LayerId, boolean>;
  rightPanelOpen?: boolean;
  drawerState?: "collapsed" | "mid" | "expanded";
  selectionSeq?: number;
  onSelectRiver: (river: FishabilityRow) => void;
  className?: string;
  initialStyleUrl?: string;
  onMapReady?: (map: mapboxgl.Map) => void;
}

const RIVERS_SOURCE = "rivers-source";
const UNCLUSTERED_LAYER = "rivers-unclustered";
const SELECTED_HALO_LAYER = "rivers-selected-halo";
const SELECTED_CORE_LAYER = "rivers-selected-core";

const ALL_RIVERS_SOURCE = "all-rivers-source";
const RIVER_LABELS_SOURCE = "river-labels-source";
const RIVER_HIT_LAYER = "rivers-hit";
const RIVER_CASING_LAYER = "rivers-casing";
const RIVER_BASE_LAYER = "rivers-base";
const RIVER_SELECTED_LAYER = "rivers-selected";
const RIVER_NAMES_LAYER = "river-labels";

const STATEWIDE_HYDRO_SOURCE = "statewide-hydrology-source";
const STATEWIDE_HYDRO_LAYER = "statewide-hydrology-line";

const FEDERAL_LANDS_SOURCE = "public-lands-federal-source";
const FEDERAL_LANDS_LAYER = "public-lands-federal-layer";
const STATE_LANDS_SOURCE = "public-lands-state-source";
const STATE_LANDS_LAYER = "public-lands-state-layer";

const ACCESS_SOURCE = "access-fishing-sites-source";
const ACCESS_LAYER = "access-fishing-sites-layer";
const ACTIVE_STATIONS_SOURCE = "active-usgs-stations-source";
const ACTIVE_STATIONS_LAYER = "active-usgs-stations-layer";
const HYDRO_FLOW_LAYER = "hydro-flow-magnitude-layer";
const HYDRO_CHANGE_LAYER = "hydro-change-indicator-layer";
const HYDRO_TEMP_LAYER = "hydro-temp-stress-layer";

const BLM_TILES =
  "https://gis.blm.gov/arcgis/rest/services/lands/BLM_Natl_SMA_Cached_without_PriUnk/MapServer/tile/{z}/{y}/{x}";
const STATE_LANDS_GEOJSON =
  "https://fwp-gis.mt.gov/arcgis/rest/services/fwplnd/fwpLands/MapServer/5/query?where=1%3D1&outFields=NAME&returnGeometry=true&f=geojson";
const FWP_ACCESS_GEOJSON =
  "https://fwp-gis.mt.gov/arcgis/rest/services/fwplnd/fwpLands/MapServer/1/query?where=1%3D1&outFields=NAME&returnGeometry=true&f=geojson";
const RIVER_ID_PROP = "river_id";
const CLICK_PRIORITY_LAYERS = [UNCLUSTERED_LAYER, ACCESS_LAYER, ACTIVE_STATIONS_LAYER] as const;
const MAPBOX_STYLES: Record<BasemapId, string> = {
  hybrid: "mapbox://styles/mapbox/satellite-streets-v12",
  satellite: "mapbox://styles/mapbox/satellite-v9",
  topo: "mapbox://styles/mapbox/outdoors-v12",
  light: "mapbox://styles/mapbox/light-v11",
  dark: "mapbox://styles/mapbox/dark-v11",
};
const BASE_STYLE = MAPBOX_STYLES.hybrid;
const MAPBOX_DEM_SOURCE = "mapbox-dem";
const MAPBOX_TOKEN = process.env.NEXT_PUBLIC_MAPBOX_TOKEN ?? "";

mapboxgl.accessToken = MAPBOX_TOKEN;

function riverIdExpr() {
  return [
    "to-string",
    [
      "coalesce",
      ["get", RIVER_ID_PROP],
      ["get", "river_uuid"],
      ["get", "riverId"],
      ["get", "id"],
      "",
    ],
  ] as any;
}

function selectedRiverFilter(selectedRiverId: string | null | undefined) {
  const sid = selectedRiverId ? String(selectedRiverId) : "";
  if (!sid) return ["==", ["literal", 1], ["literal", 0]] as any;
  return ["==", riverIdExpr(), sid] as any;
}

function extractRiverId(properties?: Record<string, unknown> | null): string | null {
  if (!properties) return null;
  const value =
    properties[RIVER_ID_PROP] ??
    properties.river_uuid ??
    properties.riverId ??
    properties.id ??
    null;
  if (value == null) return null;
  const s = String(value).trim();
  return s.length > 0 ? s : null;
}

function normalizeGeojson(g: GeoJSON.GeoJSON | null): GeoJSON.GeoJSON | null {
  if (!g) return null;
  if (g.type === "FeatureCollection") return g;
  if (g.type === "Feature") return g;
  if (g.type === "LineString" || g.type === "MultiLineString") {
    return { type: "Feature", properties: {}, geometry: g } as GeoJSON.Feature;
  }
  return g;
}

function getStationTooltipHtml(properties: Record<string, unknown>) {
  const stationName = String(properties.station_name ?? properties.site_no ?? "USGS Station");
  const siteNo = String(properties.site_no ?? "").trim();
  const sourceRoles = String(properties.selected_source_roles ?? "").trim();
  const selectedName = String(properties.selected_river_name ?? "").trim();
  const sourceLabel =
    sourceRoles && selectedName
      ? `Source station for ${selectedName}: ${sourceRoles}`
      : sourceRoles
        ? `Source station: ${sourceRoles}`
        : "USGS monitoring station";

  return `<div style="min-width:168px;font-size:11px;line-height:1.35;color:#0f172a;">
    <div style="font-weight:700;">${escapeHtml(stationName)}</div>
    <div style="margin-top:2px;font-size:10px;color:#475569;">${escapeHtml(siteNo || "USGS site")}</div>
    <div style="margin-top:5px;font-size:10px;color:#1e293b;">${escapeHtml(sourceLabel)}</div>
  </div>`;
}

function escapeHtml(value: unknown): string {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function withSelectedRiverMetadata(
  g: GeoJSON.GeoJSON,
  selectedRiverId?: string | null,
  selectedRiverName?: string | null
): GeoJSON.GeoJSON {
  if (!selectedRiverName && !selectedRiverId) return g;
  if (g.type === "Feature") {
    const props = { ...(g.properties ?? {}) } as Record<string, unknown>;
    const hasRiverId =
      props.river_id != null || props.river_uuid != null || props.riverId != null || props.id != null;
    return {
      ...g,
      properties: {
        ...props,
        ...(!hasRiverId && selectedRiverId ? { river_id: selectedRiverId } : {}),
        ...(selectedRiverName ? { name: selectedRiverName, river_name: selectedRiverName } : {}),
      },
    };
  }
  if (g.type === "FeatureCollection") {
    return {
      ...g,
      features: g.features.map((f) => ({
        ...f,
        properties: (() => {
          const props = { ...(f.properties ?? {}) } as Record<string, unknown>;
          const hasRiverId =
            props.river_id != null || props.river_uuid != null || props.riverId != null || props.id != null;
          return {
            ...props,
            ...(!hasRiverId && selectedRiverId ? { river_id: selectedRiverId } : {}),
            ...(selectedRiverName ? { name: selectedRiverName, river_name: selectedRiverName } : {}),
          };
        })(),
      })),
    };
  }
  return {
    type: "Feature",
    properties: {
      ...(selectedRiverId ? { river_id: selectedRiverId } : {}),
      ...(selectedRiverName ? { name: selectedRiverName, river_name: selectedRiverName } : {}),
    },
    geometry: g as GeoJSON.Geometry,
  } as GeoJSON.Feature;
}

function toneRasterBasemap(map: mapboxgl.Map) {
  const style = map.getStyle();
  const rasterLayers = (style.layers ?? []).filter((layer) => layer.type === "raster");
  let tonedCount = 0;

  for (const layer of rasterLayers) {
    const id = layer.id ?? "";
    const lid = id.toLowerCase();
    const isImagery =
      !lid.includes("label") &&
      !lid.includes("reference") &&
      !lid.includes("boundaries") &&
      id !== FEDERAL_LANDS_LAYER;
    if (!isImagery) continue;

    try {
      map.setPaintProperty(id, "raster-saturation", -0.15);
      map.setPaintProperty(id, "raster-brightness-min", 0.05);
      map.setPaintProperty(id, "raster-brightness-max", 0.95);
      tonedCount += 1;
    } catch {
      /* ignore per-layer paint failures */
    }
  }

  if (tonedCount === 0 && rasterLayers.length > 0) {
    // Useful when style ids change across providers.
    console.log(
      "MAP RASTER LAYERS",
      rasterLayers.map((layer) => ({ id: layer.id, type: layer.type }))
    );
  }
}

function geojsonBbox(geojson: GeoJSON.GeoJSON): [number, number, number, number] | null {
  const coords: [number, number][] = [];
  const collect = (g: GeoJSON.Geometry) => {
    if (g.type === "Point") coords.push(g.coordinates as [number, number]);
    else if (g.type === "LineString") {
      for (const c of g.coordinates) coords.push(c as [number, number]);
    } else if (g.type === "MultiLineString") {
      for (const line of g.coordinates) for (const c of line) coords.push(c as [number, number]);
    } else if (g.type === "Polygon") {
      for (const ring of g.coordinates) for (const c of ring) coords.push(c as [number, number]);
    } else if (g.type === "MultiPoint") {
      for (const c of g.coordinates) coords.push(c as [number, number]);
    }
  };

  if ("geometry" in geojson && geojson.geometry) collect(geojson.geometry);
  else if ("coordinates" in geojson) collect(geojson as GeoJSON.Geometry);
  else if ("features" in geojson) {
    for (const f of geojson.features) if (f.geometry) collect(f.geometry);
  }

  if (!coords.length) return null;
  const lons = coords.map((c) => c[0]);
  const lats = coords.map((c) => c[1]);
  return [Math.min(...lons), Math.min(...lats), Math.max(...lons), Math.max(...lats)];
}

export function computeBboxFromGeoJSON(
  features: Array<GeoJSON.Feature<GeoJSON.Geometry, Record<string, unknown>>>
): [number, number, number, number] | null {
  let minLng = Infinity;
  let minLat = Infinity;
  let maxLng = -Infinity;
  let maxLat = -Infinity;
  let hasAny = false;

  const pushCoord = (coord: number[]) => {
    const lng = coord[0];
    const lat = coord[1];
    if (!Number.isFinite(lng) || !Number.isFinite(lat)) return;
    minLng = Math.min(minLng, lng);
    minLat = Math.min(minLat, lat);
    maxLng = Math.max(maxLng, lng);
    maxLat = Math.max(maxLat, lat);
    hasAny = true;
  };

  for (const feature of features) {
    const geom = feature.geometry;
    if (!geom) continue;
    if (geom.type === "LineString") {
      for (const c of geom.coordinates) pushCoord(c as number[]);
      continue;
    }
    if (geom.type === "MultiLineString") {
      for (const seg of geom.coordinates) {
        for (const c of seg) pushCoord(c as number[]);
      }
    }
  }

  if (!hasAny) return null;
  return [minLng, minLat, maxLng, maxLat];
}

function selectedRiverBoundsFromGeojson(
  geojson: GeoJSON.GeoJSON | null | undefined,
  selectedId: string | null | undefined
): [number, number, number, number] | null {
  if (!geojson || !selectedId) return null;
  const sid = String(selectedId);

  const collectFeatures = (): Array<GeoJSON.Feature<GeoJSON.Geometry, Record<string, unknown>>> => {
    if (geojson.type === "FeatureCollection") {
      return geojson.features
        .filter((f): f is GeoJSON.Feature<GeoJSON.Geometry, Record<string, unknown>> => Boolean(f?.geometry))
        .filter((f) => extractRiverId((f.properties as Record<string, unknown> | undefined) ?? null) === sid);
    }
    if (geojson.type === "Feature") {
      if (!geojson.geometry) return [];
      const rid = extractRiverId((geojson.properties as Record<string, unknown> | undefined) ?? null);
      return rid === sid ? [geojson as GeoJSON.Feature<GeoJSON.Geometry, Record<string, unknown>>] : [];
    }
    if (geojson.type === "LineString" || geojson.type === "MultiLineString") {
      return [{ type: "Feature", geometry: geojson, properties: { river_id: sid } }];
    }
    return [];
  };

  const selectedFeatures = collectFeatures();
  return computeBboxFromGeoJSON(selectedFeatures);
}

function riversToFeatureCollection(
  rivers: FishabilityRow[]
): GeoJSON.FeatureCollection<GeoJSON.Point, Record<string, unknown>> {
  const features: GeoJSON.Feature<GeoJSON.Point, Record<string, unknown>>[] = [];

  for (const river of rivers) {
    const lat = river.lat ?? (river as { latitude?: number }).latitude;
    const lng = river.lng ?? (river as { longitude?: number }).longitude;
    const coords: [number, number] | undefined =
      lat != null && lng != null ? [lng, lat] : RIVER_FOCUS_POINTS[river.river_id];
    if (!coords) continue;

    features.push({
      type: "Feature",
      geometry: { type: "Point", coordinates: coords },
      properties: {
        river_id: river.river_id,
        river_name: river.river_name,
        bite_tier: river.bite_tier ?? null,
        fishability_score: river.fishability_score_calc ?? null,
        flow_ratio_calc: river.flow_ratio_calc ?? null,
        change_48h_pct_calc: river.change_48h_pct_calc ?? null,
        water_temp_f: river.water_temp_f ?? null,
      },
    });
  }

  return { type: "FeatureCollection", features };
}

function ensureRiversSource(map: mapboxgl.Map, rivers: FishabilityRow[]) {
  const fc = riversToFeatureCollection(rivers);
  const src = map.getSource(RIVERS_SOURCE) as
    | { setData?: (d: GeoJSON.FeatureCollection) => void }
    | undefined;

  if (!src) {
    map.addSource(RIVERS_SOURCE, {
      type: "geojson",
      data: fc,
      cluster: false,
      generateId: true,
    });
    return;
  }
  src.setData?.(fc);
}

function ensureRiverPointLayers(map: mapboxgl.Map) {
  if (!map.getLayer(UNCLUSTERED_LAYER)) {
    map.addLayer({
      id: UNCLUSTERED_LAYER,
      type: "circle",
      source: RIVERS_SOURCE,
      filter: ["==", ["geometry-type"], "Point"],
      paint: {
        "circle-color": [
          "case",
          ["==", ["get", "bite_tier"], "HOT"], BITE_TIER_COLORS.HOT,
          ["==", ["get", "bite_tier"], "GOOD"], BITE_TIER_COLORS.GOOD,
          ["==", ["get", "bite_tier"], "FAIR"], BITE_TIER_COLORS.FAIR,
          ["==", ["get", "bite_tier"], "TOUGH"], BITE_TIER_COLORS.TOUGH,
          MRI_COLORS.tough,
        ],
        "circle-radius": ["case", ["boolean", ["feature-state", "hover"], false], 8, 6],
        "circle-stroke-color": "rgba(255,255,255,0.92)",
        "circle-stroke-width": ["case", ["boolean", ["feature-state", "hover"], false], 2.5, 2],
        "circle-opacity": 0.95,
      },
    });
  }

  if (!map.getLayer(SELECTED_HALO_LAYER)) {
    map.addLayer({
      id: SELECTED_HALO_LAYER,
      type: "circle",
      source: RIVERS_SOURCE,
      filter: ["==", ["get", "river_id"], "__none__"],
      paint: { "circle-color": MRI_COLORS.riverHalo, "circle-radius": 15 },
    });
  }

  if (!map.getLayer(SELECTED_CORE_LAYER)) {
    map.addLayer({
      id: SELECTED_CORE_LAYER,
      type: "circle",
      source: RIVERS_SOURCE,
      filter: ["==", ["get", "river_id"], "__none__"],
      paint: {
        "circle-color": "rgba(233,240,247,0.98)",
        "circle-radius": 6,
        "circle-stroke-color": MRI_COLORS.riverSelected,
        "circle-stroke-width": 2,
      },
    });
  }
}

function syncRiverPointPresentation(
  map: mapboxgl.Map,
  selectedRiverId: string | null,
  showMarkers: boolean,
  scoreColoring: boolean
) {
  const rid = selectedRiverId ?? "__none__";
  const visibility = showMarkers ? "visible" : "none";

  for (const layerId of [UNCLUSTERED_LAYER, SELECTED_HALO_LAYER, SELECTED_CORE_LAYER]) {
    if (map.getLayer(layerId)) {
      map.setLayoutProperty(layerId, "visibility", visibility);
    }
  }

  if (map.getLayer(SELECTED_HALO_LAYER)) {
    map.setFilter(SELECTED_HALO_LAYER, ["==", ["get", "river_id"], rid]);
  }
  if (map.getLayer(SELECTED_CORE_LAYER)) {
    map.setFilter(SELECTED_CORE_LAYER, ["==", ["get", "river_id"], rid]);
  }

  if (!map.getLayer(UNCLUSTERED_LAYER)) return;

  const circleColor = scoreColoring
    ? [
        "case",
        ["==", ["get", "bite_tier"], "HOT"], BITE_TIER_COLORS.HOT,
        ["==", ["get", "bite_tier"], "GOOD"], BITE_TIER_COLORS.GOOD,
        ["==", ["get", "bite_tier"], "FAIR"], BITE_TIER_COLORS.FAIR,
        ["==", ["get", "bite_tier"], "TOUGH"], BITE_TIER_COLORS.TOUGH,
        MRI_COLORS.tough,
      ]
    : MRI_COLORS.tough;
  map.setPaintProperty(UNCLUSTERED_LAYER, "circle-color", circleColor as any);

  const circleOpacity = selectedRiverId
    ? ["case", ["==", ["get", "river_id"], selectedRiverId], 0.95, 0.38]
    : 0.95;
  map.setPaintProperty(UNCLUSTERED_LAYER, "circle-opacity", circleOpacity as any);
}

function clearSelectedRiverLine(map: mapboxgl.Map) {
  if (map.getLayer(RIVER_NAMES_LAYER)) map.removeLayer(RIVER_NAMES_LAYER);
  if (map.getLayer(RIVER_HIT_LAYER)) map.removeLayer(RIVER_HIT_LAYER);
  if (map.getLayer(RIVER_SELECTED_LAYER)) map.removeLayer(RIVER_SELECTED_LAYER);
  if (map.getLayer(RIVER_BASE_LAYER)) map.removeLayer(RIVER_BASE_LAYER);
  if (map.getLayer(RIVER_CASING_LAYER)) map.removeLayer(RIVER_CASING_LAYER);
  if (map.getSource(RIVER_LABELS_SOURCE)) map.removeSource(RIVER_LABELS_SOURCE);
  if (map.getSource(ALL_RIVERS_SOURCE)) map.removeSource(ALL_RIVERS_SOURCE);
}

function toLineLabelFeatures(
  geojson: GeoJSON.GeoJSON
): GeoJSON.FeatureCollection<GeoJSON.LineString, Record<string, unknown>> {
  const bestByRiver = new Map<string, GeoJSON.Feature<GeoJSON.LineString, Record<string, unknown>>>();
  const scoreLine = (coords: number[][]) => coords.length;
  const pushCandidate = (props: Record<string, unknown>, coords: number[][]) => {
    const riverId =
      String(props.river_id ?? props.river_uuid ?? props.riverId ?? props.id ?? "").trim();
    if (!riverId || !coords?.length) return;
    const candidate: GeoJSON.Feature<GeoJSON.LineString, Record<string, unknown>> = {
      type: "Feature",
      properties: props,
      geometry: { type: "LineString", coordinates: coords as [number, number][] },
    };
    const existing = bestByRiver.get(riverId);
    if (!existing || scoreLine(existing.geometry.coordinates as number[][]) < scoreLine(coords)) {
      bestByRiver.set(riverId, candidate);
    }
  };

  const handleFeature = (f: GeoJSON.Feature) => {
    if (!f.geometry) return;
    const props = { ...(f.properties ?? {}) } as Record<string, unknown>;
    if (f.geometry.type === "LineString") {
      pushCandidate(props, f.geometry.coordinates as number[][]);
      return;
    }
    if (f.geometry.type === "MultiLineString") {
      for (const seg of f.geometry.coordinates) pushCandidate(props, seg as number[][]);
    }
  };

  if (geojson.type === "FeatureCollection") {
    for (const f of geojson.features) handleFeature(f);
  } else if (geojson.type === "Feature") {
    handleFeature(geojson);
  } else if (geojson.type === "LineString") {
    handleFeature({ type: "Feature", properties: {}, geometry: geojson });
  } else if (geojson.type === "MultiLineString") {
    handleFeature({ type: "Feature", properties: {}, geometry: geojson });
  }

  return { type: "FeatureCollection", features: Array.from(bestByRiver.values()) };
}

function syncSelectedRiverLine(
  map: mapboxgl.Map,
  geojson: GeoJSON.GeoJSON | null,
  selectedRiverId: string | null | undefined,
  selectedRiverName: string | null | undefined,
  showRiverLines: boolean,
  showSelectedHighlight: boolean,
  showLabels: boolean
) {
  const highlightEnabled = showRiverLines && showSelectedHighlight;
  if (!geojson || (!showRiverLines && !highlightEnabled)) {
    clearSelectedRiverLine(map);
    return;
  }

  const data = normalizeGeojson(geojson);
  if (!data) return;
  const namedData = withSelectedRiverMetadata(data, selectedRiverId, selectedRiverName);
  const rid = selectedRiverId ? String(selectedRiverId) : "";
  const selectedFilter = selectedRiverFilter(rid);

  const src = map.getSource(ALL_RIVERS_SOURCE) as
    | { setData?: (d: GeoJSON.GeoJSON) => void }
    | undefined;

  if (!src) {
    map.addSource(ALL_RIVERS_SOURCE, { type: "geojson", data: namedData });
  } else {
    src.setData?.(namedData);
  }

  if (showRiverLines && !map.getLayer(RIVER_CASING_LAYER)) {
    map.addLayer({
      id: RIVER_CASING_LAYER,
      type: "line",
      source: ALL_RIVERS_SOURCE,
      minzoom: 4,
      maxzoom: 24,
      layout: { "line-join": "round", "line-cap": "round" },
      paint: {
        "line-color": "#0b1e28",
        "line-width": [
          "interpolate",
          ["linear"],
          ["zoom"],
          4, 2.2,
          6, 3.2,
          8, 4.7,
          10, 6.2,
          12, 8.4,
        ],
        "line-opacity": 0.82,
      },
    });
  } else if (!showRiverLines && map.getLayer(RIVER_CASING_LAYER)) {
    map.removeLayer(RIVER_CASING_LAYER);
  }

  if (showRiverLines && !map.getLayer(RIVER_BASE_LAYER)) {
    map.addLayer({
      id: RIVER_BASE_LAYER,
      type: "line",
      source: ALL_RIVERS_SOURCE,
      minzoom: 4,
      maxzoom: 24,
      layout: { "line-join": "round", "line-cap": "round" },
      paint: {
        "line-color": "#4aa3ff",
        "line-width": [
          "interpolate",
          ["linear"],
          ["zoom"],
          4, 1.15,
          6, 1.9,
          8, 2.9,
          10, 4.15,
          12, 5.5,
        ],
        "line-opacity": 0.8,
      },
    });
  } else if (!showRiverLines && map.getLayer(RIVER_BASE_LAYER)) {
    map.removeLayer(RIVER_BASE_LAYER);
  }

  if (showRiverLines && !map.getLayer(RIVER_HIT_LAYER)) {
    map.addLayer({
      id: RIVER_HIT_LAYER,
      type: "line",
      source: ALL_RIVERS_SOURCE,
      minzoom: 4,
      maxzoom: 24,
      layout: { "line-join": "round", "line-cap": "round" },
      paint: {
        "line-color": "rgba(0,0,0,0)",
        "line-width": [
          "interpolate",
          ["linear"],
          ["zoom"],
          4, 12,
          6, 16,
          8, 20,
          10, 24,
          12, 28,
        ],
        "line-opacity": 0,
      },
    });
  } else if (!showRiverLines && map.getLayer(RIVER_HIT_LAYER)) {
    map.removeLayer(RIVER_HIT_LAYER);
  }

  if (highlightEnabled && !map.getLayer(RIVER_SELECTED_LAYER)) {
    map.addLayer({
      id: RIVER_SELECTED_LAYER,
      type: "line",
      source: ALL_RIVERS_SOURCE,
      filter: selectedFilter,
      minzoom: 4,
      maxzoom: 24,
      layout: { "line-join": "round", "line-cap": "round" },
      paint: {
        "line-color": "#8fd0ff",
        "line-width": [
          "interpolate",
          ["linear"],
          ["zoom"],
          4, 4.8,
          6, 6.8,
          8, 9.2,
          10, 12,
          12, 15.2,
        ],
        "line-opacity": 1,
        "line-blur": 0.2,
      },
    });
  } else if (!highlightEnabled && map.getLayer(RIVER_SELECTED_LAYER)) {
    map.removeLayer(RIVER_SELECTED_LAYER);
  }

  if (map.getLayer(RIVER_CASING_LAYER)) {
    map.setPaintProperty(RIVER_CASING_LAYER, "line-width", [
      "interpolate",
      ["linear"],
      ["zoom"],
      4, 2.2,
      6, 3.2,
      8, 4.7,
      10, 6.2,
      12, 8.4,
    ] as any);
    map.setPaintProperty(RIVER_CASING_LAYER, "line-opacity", 0.82 as any);
  }
  if (map.getLayer(RIVER_BASE_LAYER)) {
    map.setPaintProperty(RIVER_BASE_LAYER, "line-width", [
      "interpolate",
      ["linear"],
      ["zoom"],
      4, 1.15,
      6, 1.9,
      8, 2.9,
      10, 4.15,
      12, 5.5,
    ] as any);
    map.setPaintProperty(RIVER_BASE_LAYER, "line-opacity", 0.8 as any);
  }
  if (map.getLayer(RIVER_HIT_LAYER)) {
    map.setPaintProperty(RIVER_HIT_LAYER, "line-width", [
      "interpolate",
      ["linear"],
      ["zoom"],
      4, 12,
      6, 16,
      8, 20,
      10, 24,
      12, 28,
    ] as any);
    map.setPaintProperty(RIVER_HIT_LAYER, "line-opacity", 0 as any);
  }
  if (map.getLayer(RIVER_SELECTED_LAYER)) {
    map.setFilter(RIVER_SELECTED_LAYER, selectedFilter);
    map.setPaintProperty(RIVER_SELECTED_LAYER, "line-width", [
      "interpolate",
      ["linear"],
      ["zoom"],
      4, 4.8,
      6, 6.8,
      8, 9.2,
      10, 12,
      12, 15.2,
    ] as any);
    map.setPaintProperty(RIVER_SELECTED_LAYER, "line-blur", 0.2 as any);
  }

  if (showLabels && !map.getLayer(RIVER_NAMES_LAYER)) {
    const labels = toLineLabelFeatures(namedData);
    const labelSrc = map.getSource(RIVER_LABELS_SOURCE) as
      | { setData?: (d: GeoJSON.FeatureCollection) => void }
      | undefined;
    if (!labelSrc) {
      map.addSource(RIVER_LABELS_SOURCE, { type: "geojson", data: labels });
    } else {
      labelSrc.setData?.(labels);
    }

    map.addLayer({
      id: RIVER_NAMES_LAYER,
      type: "symbol",
      source: RIVER_LABELS_SOURCE,
      minzoom: 7,
      layout: {
        "symbol-placement": "line",
        "symbol-spacing": 500,
        "text-field": ["coalesce", ["get", "river_name"], ["get", "name"], ""],
        "text-size": ["interpolate", ["linear"], ["zoom"], 7, 11, 10, 13, 12, 15],
        "text-font": ["Open Sans Semibold", "Arial Unicode MS Bold"],
        "text-allow-overlap": false,
        "text-ignore-placement": false,
        "text-padding": 2,
        "text-max-angle": 30,
        "text-letter-spacing": 0.02,
      },
      paint: {
        "text-color": "rgba(188,204,219,0.9)",
        "text-opacity": ["interpolate", ["linear"], ["zoom"], 7, 0, 8, 0.6, 10, 0.82],
        "text-halo-color": "rgba(14,22,32,0.88)",
        "text-halo-width": 1,
        "text-halo-blur": 0.5,
      },
    });
  } else if (showLabels && map.getLayer(RIVER_NAMES_LAYER)) {
    const labels = toLineLabelFeatures(namedData);
    const labelSrc = map.getSource(RIVER_LABELS_SOURCE) as
      | { setData?: (d: GeoJSON.FeatureCollection) => void }
      | undefined;
    labelSrc?.setData?.(labels);
  } else if (!showLabels && map.getLayer(RIVER_NAMES_LAYER)) {
    map.removeLayer(RIVER_NAMES_LAYER);
    if (map.getSource(RIVER_LABELS_SOURCE)) map.removeSource(RIVER_LABELS_SOURCE);
  }

  try {
    if (map.getLayer(STATEWIDE_HYDRO_LAYER) && map.getLayer(RIVER_SELECTED_LAYER)) {
      map.moveLayer(RIVER_SELECTED_LAYER);
    }
    if (map.getLayer(RIVER_CASING_LAYER) && map.getLayer(UNCLUSTERED_LAYER)) {
      map.moveLayer(RIVER_CASING_LAYER, UNCLUSTERED_LAYER);
    }
    if (map.getLayer(RIVER_BASE_LAYER) && map.getLayer(UNCLUSTERED_LAYER)) {
      map.moveLayer(RIVER_BASE_LAYER, UNCLUSTERED_LAYER);
    }
    if (map.getLayer(RIVER_SELECTED_LAYER) && map.getLayer(UNCLUSTERED_LAYER)) {
      map.moveLayer(RIVER_SELECTED_LAYER, UNCLUSTERED_LAYER);
    }
    if (map.getLayer(RIVER_HIT_LAYER) && map.getLayer(UNCLUSTERED_LAYER)) {
      map.moveLayer(RIVER_HIT_LAYER, UNCLUSTERED_LAYER);
    }
    if (map.getLayer(RIVER_NAMES_LAYER) && map.getLayer(UNCLUSTERED_LAYER)) {
      map.moveLayer(RIVER_NAMES_LAYER, UNCLUSTERED_LAYER);
    }
    if (map.getLayer(UNCLUSTERED_LAYER)) {
      map.moveLayer(UNCLUSTERED_LAYER);
    }
    if (map.getLayer(SELECTED_HALO_LAYER)) {
      map.moveLayer(SELECTED_HALO_LAYER);
    }
    if (map.getLayer(SELECTED_CORE_LAYER)) {
      map.moveLayer(SELECTED_CORE_LAYER);
    }
  } catch {
    /* ignore */
  }
}

function syncStatewideHydrologyLayer(map: mapboxgl.Map, enabled: boolean) {
  if (enabled) {
    if (!map.getSource(STATEWIDE_HYDRO_SOURCE)) {
      map.addSource(STATEWIDE_HYDRO_SOURCE, {
        type: "geojson",
        data: "https://hydro.nationalmap.gov/arcgis/rest/services/nhd/MapServer/2/query?where=1%3D1&geometry=-116.2,44.2,-104,49.2&geometryType=esriGeometryEnvelope&inSR=4326&spatialRel=esriSpatialRelIntersects&outFields=GNIS_NAME&returnGeometry=true&geometryPrecision=4&maxAllowableOffset=0.005&f=geojson" as any,
      } as any);
    }
    if (!map.getLayer(STATEWIDE_HYDRO_LAYER)) {
      map.addLayer({
        id: STATEWIDE_HYDRO_LAYER,
        type: "line",
        source: STATEWIDE_HYDRO_SOURCE,
        paint: {
          "line-color": MRI_COLORS.riverCasing,
          "line-width": ["interpolate", ["linear"], ["zoom"], 5, 0.35, 8, 0.55, 11, 0.9],
          "line-opacity": 0.7,
        },
      });
    }
    try {
      if (map.getLayer(RIVER_CASING_LAYER)) {
        map.moveLayer(STATEWIDE_HYDRO_LAYER, RIVER_CASING_LAYER);
      } else if (map.getLayer(UNCLUSTERED_LAYER)) {
        map.moveLayer(STATEWIDE_HYDRO_LAYER, UNCLUSTERED_LAYER);
      }
    } catch {
      /* ignore */
    }
    return;
  }
  if (map.getLayer(STATEWIDE_HYDRO_LAYER)) map.removeLayer(STATEWIDE_HYDRO_LAYER);
}

function syncFederalLandsLayer(map: mapboxgl.Map, enabled: boolean) {
  if (enabled) {
    if (!map.getSource(FEDERAL_LANDS_SOURCE)) {
      map.addSource(FEDERAL_LANDS_SOURCE, {
        type: "raster",
        tiles: [BLM_TILES],
        tileSize: 256,
        attribution: "BLM Surface Management Agency",
      });
    }
    if (!map.getLayer(FEDERAL_LANDS_LAYER)) {
      map.addLayer({
        id: FEDERAL_LANDS_LAYER,
        type: "raster",
        source: FEDERAL_LANDS_SOURCE,
        minzoom: 8,
        paint: {
          "raster-opacity": 0.16,
          "raster-saturation": -0.72,
          "raster-contrast": -0.28,
          "raster-brightness-min": 0.22,
          "raster-brightness-max": 0.86,
        },
      });
    }
    try {
      if (map.getLayer(STATEWIDE_HYDRO_LAYER)) {
        map.moveLayer(FEDERAL_LANDS_LAYER, STATEWIDE_HYDRO_LAYER);
      } else if (map.getLayer(RIVER_CASING_LAYER)) {
        map.moveLayer(FEDERAL_LANDS_LAYER, RIVER_CASING_LAYER);
      }
    } catch {
      /* ignore */
    }
    return;
  }

  if (map.getLayer(FEDERAL_LANDS_LAYER)) {
    map.removeLayer(FEDERAL_LANDS_LAYER);
  }
}

function syncStateLandsLayer(map: mapboxgl.Map, enabled: boolean) {
  if (enabled) {
    if (!map.getSource(STATE_LANDS_SOURCE)) {
      map.addSource(STATE_LANDS_SOURCE, {
        type: "geojson",
        data: STATE_LANDS_GEOJSON as any,
      } as any);
    }
    if (!map.getLayer(STATE_LANDS_LAYER)) {
      map.addLayer({
        id: STATE_LANDS_LAYER,
        type: "fill",
        source: STATE_LANDS_SOURCE,
        minzoom: 8,
        paint: {
          "fill-color": "#5f725e",
          "fill-opacity": 0.12,
          "fill-outline-color": "rgba(148,163,184,0.3)",
        },
      });
    }
    try {
      if (map.getLayer(STATEWIDE_HYDRO_LAYER)) {
        map.moveLayer(STATE_LANDS_LAYER, STATEWIDE_HYDRO_LAYER);
      } else if (map.getLayer(RIVER_CASING_LAYER)) {
        map.moveLayer(STATE_LANDS_LAYER, RIVER_CASING_LAYER);
      }
    } catch {
      /* ignore */
    }
    return;
  }
  if (map.getLayer(STATE_LANDS_LAYER)) {
    map.removeLayer(STATE_LANDS_LAYER);
  }
}

function syncFishingAccessLayer(map: mapboxgl.Map, enabled: boolean) {
  if (enabled) {
    if (!map.getSource(ACCESS_SOURCE)) {
      map.addSource(ACCESS_SOURCE, {
        type: "geojson",
        data: FWP_ACCESS_GEOJSON as any,
      } as any);
    }
    if (!map.getLayer(ACCESS_LAYER)) {
      map.addLayer({
        id: ACCESS_LAYER,
        type: "circle",
        source: ACCESS_SOURCE,
        minzoom: 8,
        paint: {
          "circle-color": "#6f8491",
          "circle-radius": ["interpolate", ["linear"], ["zoom"], 8, 2.4, 11, 4.6],
          "circle-stroke-color": "#e2e8f0",
          "circle-stroke-width": 1,
          "circle-opacity": 0.88,
        },
      });
    }
    try {
      if (map.getLayer(UNCLUSTERED_LAYER)) {
        map.moveLayer(ACCESS_LAYER, UNCLUSTERED_LAYER);
      }
    } catch {
      /* ignore */
    }
    return;
  }

  if (map.getLayer(ACCESS_LAYER)) {
    map.removeLayer(ACCESS_LAYER);
  }
}

function syncActiveStationsLayer(
  map: mapboxgl.Map,
  enabled: boolean,
  stationsGeojson: GeoJSON.FeatureCollection<GeoJSON.Point, Record<string, unknown>> | null | undefined,
  selectedRiver: FishabilityRow | null | undefined
) {
  const hasFeatures = Boolean(stationsGeojson?.features?.length);
  if (!enabled || !hasFeatures) {
    if (map.getLayer(ACTIVE_STATIONS_LAYER)) {
      map.removeLayer(ACTIVE_STATIONS_LAYER);
    }
    if (map.getSource(ACTIVE_STATIONS_SOURCE)) {
      map.removeSource(ACTIVE_STATIONS_SOURCE);
    }
    return;
  }

  const selectedFlowSiteNo = selectedRiver?.flow_source_site_no ? String(selectedRiver.flow_source_site_no) : "";
  const selectedTempSiteNo = selectedRiver?.temp_source_site_no ? String(selectedRiver.temp_source_site_no) : "";
  const selectedRiverName = selectedRiver?.river_name ?? null;
  const selectedRiverId = selectedRiver?.river_id ? String(selectedRiver.river_id) : null;

  const annotatedStations: GeoJSON.FeatureCollection<GeoJSON.Point, Record<string, unknown>> = {
    type: "FeatureCollection",
    features: (stationsGeojson?.features ?? []).map((feature) => {
      const props = { ...(feature.properties ?? {}) } as Record<string, unknown>;
      const siteNo = props.site_no != null ? String(props.site_no) : "";
      const isFlowSource = Boolean(selectedFlowSiteNo && siteNo === selectedFlowSiteNo);
      const isTempSource = Boolean(selectedTempSiteNo && siteNo === selectedTempSiteNo);
      return {
        ...feature,
        properties: {
          ...props,
          is_selected_source: isFlowSource || isTempSource,
          is_selected_flow_source: isFlowSource,
          is_selected_temp_source: isTempSource,
          selected_source_roles: [isFlowSource ? "flow" : null, isTempSource ? "temp" : null]
            .filter(Boolean)
            .join(" + "),
          selected_river_name: selectedRiverName,
          selected_river_id: selectedRiverId,
        },
      };
    }),
  };

  const src = map.getSource(ACTIVE_STATIONS_SOURCE) as
    | { setData?: (d: GeoJSON.FeatureCollection) => void }
    | undefined;

  if (!src) {
    map.addSource(ACTIVE_STATIONS_SOURCE, {
      type: "geojson",
      data: annotatedStations,
    });
  } else {
    src.setData?.(annotatedStations);
  }

  if (!map.getLayer(ACTIVE_STATIONS_LAYER)) {
    map.addLayer({
      id: ACTIVE_STATIONS_LAYER,
      type: "circle",
      source: ACTIVE_STATIONS_SOURCE,
      minzoom: 5,
      paint: {
        "circle-color": [
          "case",
          ["==", ["get", "is_selected_source"], true],
          "#dff4ff",
          "#f8fbff",
        ],
        "circle-radius": [
          "interpolate",
          ["linear"],
          ["zoom"],
          5, ["case", ["==", ["get", "is_selected_source"], true], 4.6, 3.1],
          9, ["case", ["==", ["get", "is_selected_source"], true], 6.1, 4.1],
          12, ["case", ["==", ["get", "is_selected_source"], true], 7.2, 5],
        ],
        "circle-stroke-color": [
          "case",
          ["==", ["get", "is_selected_source"], true],
          "rgba(95,183,255,0.95)",
          "rgba(8,19,28,0.96)",
        ],
        "circle-stroke-width": ["case", ["==", ["get", "is_selected_source"], true], 2, 1.3],
        "circle-opacity": 0.96,
        "circle-blur": 0.03,
      },
    });
  }

  try {
    if (map.getLayer(UNCLUSTERED_LAYER)) {
      map.moveLayer(ACTIVE_STATIONS_LAYER, UNCLUSTERED_LAYER);
    }
  } catch {
    /* ignore */
  }
}

function syncHydrologyOverlays(
  map: mapboxgl.Map,
  showFlowMagnitude: boolean,
  showChangeIndicator: boolean,
  showTempStress: boolean
) {
  if (showFlowMagnitude) {
    if (!map.getLayer(HYDRO_FLOW_LAYER)) {
      map.addLayer({
        id: HYDRO_FLOW_LAYER,
        type: "circle",
        source: RIVERS_SOURCE,
        filter: ["==", ["geometry-type"], "Point"],
        paint: {
          "circle-color": [
            "interpolate",
            ["linear"],
            ["coalesce", ["get", "flow_ratio_calc"], 1],
            0.4, MRI_COLORS.riverSelected,
            0.8, MRI_COLORS.good,
            1.0, MRI_COLORS.fair,
            1.5, MRI_COLORS.warning,
            2.0, MRI_COLORS.warning,
          ],
          "circle-radius": ["interpolate", ["linear"], ["zoom"], 5, 2.5, 9, 4.2, 12, 5.2],
          "circle-opacity": 0.8,
        },
      });
    }
  } else if (map.getLayer(HYDRO_FLOW_LAYER)) {
    map.removeLayer(HYDRO_FLOW_LAYER);
  }

  if (showChangeIndicator) {
    if (!map.getLayer(HYDRO_CHANGE_LAYER)) {
      map.addLayer({
        id: HYDRO_CHANGE_LAYER,
        type: "symbol",
        source: RIVERS_SOURCE,
        filter: ["==", ["geometry-type"], "Point"],
        layout: {
          "text-field": [
            "case",
            [">", ["coalesce", ["get", "change_48h_pct_calc"], 0], 12], "▲",
            ["<", ["coalesce", ["get", "change_48h_pct_calc"], 0], -12], "▼",
            "•",
          ],
          "text-size": ["interpolate", ["linear"], ["zoom"], 6, 9, 10, 12],
          "text-offset": [0, 1.3],
        },
        paint: {
          "text-color": [
            "case",
            [">", ["coalesce", ["get", "change_48h_pct_calc"], 0], 12], MRI_COLORS.good,
            ["<", ["coalesce", ["get", "change_48h_pct_calc"], 0], -12], MRI_COLORS.warning,
            "#94a3b8",
          ],
          "text-halo-color": "rgba(15,23,42,0.9)",
          "text-halo-width": 1,
        },
      });
    }
  } else if (map.getLayer(HYDRO_CHANGE_LAYER)) {
    map.removeLayer(HYDRO_CHANGE_LAYER);
  }

  if (showTempStress) {
    if (!map.getLayer(HYDRO_TEMP_LAYER)) {
      map.addLayer({
        id: HYDRO_TEMP_LAYER,
        type: "circle",
        source: RIVERS_SOURCE,
        filter: [
          "all",
          ["==", ["geometry-type"], "Point"],
          [">=", ["coalesce", ["get", "water_temp_f"], 0], 67],
        ],
        paint: {
          "circle-color": MRI_COLORS.warning,
          "circle-radius": ["interpolate", ["linear"], ["zoom"], 6, 5, 10, 7.5],
          "circle-stroke-color": "rgba(255,255,255,0.95)",
          "circle-stroke-width": 1.2,
          "circle-opacity": 0.8,
        },
      });
    }
  } else if (map.getLayer(HYDRO_TEMP_LAYER)) {
    map.removeLayer(HYDRO_TEMP_LAYER);
  }

  try {
    if (map.getLayer(HYDRO_FLOW_LAYER) && map.getLayer(UNCLUSTERED_LAYER)) {
      map.moveLayer(HYDRO_FLOW_LAYER, UNCLUSTERED_LAYER);
    }
    if (map.getLayer(HYDRO_CHANGE_LAYER) && map.getLayer(UNCLUSTERED_LAYER)) {
      map.moveLayer(HYDRO_CHANGE_LAYER, UNCLUSTERED_LAYER);
    }
    if (map.getLayer(HYDRO_TEMP_LAYER) && map.getLayer(UNCLUSTERED_LAYER)) {
      map.moveLayer(HYDRO_TEMP_LAYER, UNCLUSTERED_LAYER);
    }
  } catch {
    /* ignore */
  }
}

function syncLabels(map: mapboxgl.Map, visible: boolean) {
  const style = map.getStyle();
  const visibility = visible ? "visible" : "none";
  for (const layer of style.layers ?? []) {
    if (!layer.id) continue;
    const id = layer.id.toLowerCase();
    if (layer.id === RIVER_NAMES_LAYER || (layer as any).source === RIVER_LABELS_SOURCE) continue;
    const hasTextField = layer.type === "symbol" && Boolean((layer as any).layout?.["text-field"]);
    if (hasTextField || id.includes("road-label") || id.includes("place-label") || id.includes("poi-label")) {
      try {
        map.setLayoutProperty(layer.id, "visibility", visibility);
      } catch {
        /* ignore */
      }
    }
  }
}

export function MapView({
  rivers,
  selectedRiver,
  selectedRiverName,
  selectedRiverId,
  selectedRiverGeojson,
  riverLinesGeojson,
  activeStationsGeojson,
  basemap = "hybrid",
  layerState,
  rightPanelOpen = false,
  drawerState = "mid",
  selectionSeq = 0,
  onSelectRiver,
  className,
  initialStyleUrl,
  onMapReady,
}: MapViewProps) {
  const effectiveLayerState = layerState ?? createDefaultLayerState();
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);
  const riversRef = useRef(rivers);
  const onSelectRiverRef = useRef(onSelectRiver);
  const selectedRiverRef = useRef(selectedRiver);
  const selectedRiverNameRef = useRef(selectedRiverName);
  const selectedRiverIdRef = useRef(selectedRiverId);
  const selectedRiverGeojsonRef = useRef(selectedRiverGeojson);
  const riverLinesGeojsonRef = useRef<GeoJSON.FeatureCollection | null>(riverLinesGeojson ?? null);
  const activeStationsGeojsonRef = useRef<
    GeoJSON.FeatureCollection<GeoJSON.Point, Record<string, unknown>> | null
  >(activeStationsGeojson ?? null);
  const currentStyleRef = useRef<string>(MAPBOX_STYLES[basemap] ?? BASE_STYLE);
  const layerStateRef = useRef<Record<LayerId, boolean>>(effectiveLayerState);
  const onMapReadyRef = useRef(onMapReady);
  const hoverIdRef = useRef<number | string | null>(null);
  const lastFlownRef = useRef<string | null>(null);
  const lastFitSignatureRef = useRef<string | null>(null);
  const [mapReady, setMapReady] = useState(false);
  const [mapInitError, setMapInitError] = useState<string | null>(null);

  riversRef.current = rivers;
  onSelectRiverRef.current = onSelectRiver;
  selectedRiverRef.current = selectedRiver;
  selectedRiverNameRef.current = selectedRiverName;
  selectedRiverIdRef.current = selectedRiverId;
  selectedRiverGeojsonRef.current = selectedRiverGeojson;
  riverLinesGeojsonRef.current = riverLinesGeojson ?? null;
  activeStationsGeojsonRef.current = activeStationsGeojson ?? null;
  layerStateRef.current = effectiveLayerState;
  onMapReadyRef.current = onMapReady;

  const syncRuntimeLayers = useCallback((map: mapboxgl.Map) => {
    toneRasterBasemap(map);
    ensureRiversSource(map, riversRef.current);
    ensureRiverPointLayers(map);
    syncRiverPointPresentation(
      map,
      selectedRiverIdRef.current,
      true,
      layerStateRef.current.mri_score_coloring
    );
    syncSelectedRiverLine(
      map,
      riverLinesGeojsonRef.current ?? selectedRiverGeojsonRef.current,
      selectedRiverIdRef.current,
      selectedRiverNameRef.current,
      layerStateRef.current.mri_river_lines,
      layerStateRef.current.mri_selected_highlight,
      layerStateRef.current.mri_labels
    );
    syncStatewideHydrologyLayer(map, layerStateRef.current.statewide_hydrology);
    syncFederalLandsLayer(map, layerStateRef.current.public_federal);
    syncStateLandsLayer(map, layerStateRef.current.public_state);
    syncFishingAccessLayer(map, layerStateRef.current.access_fishing_sites);
    syncActiveStationsLayer(
      map,
      layerStateRef.current.mri_active_stations,
      activeStationsGeojsonRef.current,
      selectedRiverRef.current
    );
    syncHydrologyOverlays(
      map,
      layerStateRef.current.hydro_flow_magnitude,
      layerStateRef.current.hydro_change_indicator,
      layerStateRef.current.hydro_temp_stress
    );
    syncLabels(map, layerStateRef.current.mri_labels);
  }, []);

  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;
    setMapInitError(null);

    if (!MAPBOX_TOKEN) {
      setMapInitError("Missing NEXT_PUBLIC_MAPBOX_TOKEN.");
      return;
    }
    const initialStyle = initialStyleUrl ?? MAPBOX_STYLES[basemap] ?? BASE_STYLE;
    currentStyleRef.current = initialStyle;

    let map: mapboxgl.Map;
    try {
      map = new mapboxgl.Map({
        container: mapContainerRef.current,
        style: initialStyle,
        center: MONTANA_CENTER,
        zoom: DEFAULT_ZOOM,
        pitch: 14,
        bearing: 0,
      });
    } catch (error) {
      const msg = error instanceof Error ? error.message : "Failed to initialize map";
      setMapInitError(msg);
      return;
    }

    map.addControl(new mapboxgl.NavigationControl(), "top-right");
    mapRef.current = map;
    const stationHoverPopup = new mapboxgl.Popup({
      closeButton: false,
      closeOnClick: false,
      offset: 10,
      className: "mri-station-tooltip",
    });

    map.on("load", () => {
      try {
        if (!map.getSource(MAPBOX_DEM_SOURCE)) {
          map.addSource(MAPBOX_DEM_SOURCE, {
            type: "raster-dem",
            url: "mapbox://mapbox.mapbox-terrain-dem-v1",
            tileSize: 512,
            maxzoom: 14,
          } as any);
        }
        map.setTerrain({ source: MAPBOX_DEM_SOURCE, exaggeration: 1.1 });
      } catch {
        // Terrain is optional; keep the map usable even when DEM/WebGL2 is unavailable.
      }
      setMapReady(true);
      onMapReadyRef.current?.(map);
      syncRuntimeLayers(map);
      map.resize();
    });

    map.on("error", (event) => {
      const msg = (event as any)?.error?.message;
      if (typeof msg === "string" && /Failed to initialize WebGL/i.test(msg)) {
        setMapInitError(msg);
      }
    });

    if (!(map as any).__mriHandlers) {
      (map as any).__mriHandlers = true;
      map.on("click", UNCLUSTERED_LAYER, (e: mapboxgl.MapLayerMouseEvent) => {
        if (e.originalEvent && "cancelBubble" in e.originalEvent) {
          (e.originalEvent as MouseEvent).cancelBubble = true;
        }
        const f = e.features?.[0];
        const rid = f?.properties?.river_id as string | undefined;
        if (!rid) return;
        const river = riversRef.current.find((r) => r.river_id === rid);
        if (river) onSelectRiverRef.current(river);
      });

      const handleRiverLineClick = (e: mapboxgl.MapLayerMouseEvent) => {
        if (!layerStateRef.current.mri_river_lines) return;
        const stationFeatures = map.queryRenderedFeatures(e.point, {
          layers: [...CLICK_PRIORITY_LAYERS],
        });
        if (stationFeatures.length > 0) return;
        const f = e.features?.[0];
        const rid = extractRiverId((f?.properties as Record<string, unknown> | undefined) ?? null)
          ?? selectedRiverIdRef.current
          ?? undefined;
        if (!rid) return;
        const river = riversRef.current.find((r) => r.river_id === rid || r.slug === rid);
        if (!river) return;
        // Force refit even if the same river is clicked again.
        lastFlownRef.current = null;
        onSelectRiverRef.current(river);
      };

      map.on("click", RIVER_HIT_LAYER, handleRiverLineClick);

      map.on("mouseenter", RIVER_HIT_LAYER, () => {
        map.getCanvas().style.cursor = "pointer";
      });
      map.on("mouseleave", RIVER_HIT_LAYER, () => {
        map.getCanvas().style.cursor = "";
      });

      map.on("mousemove", UNCLUSTERED_LAYER, (e: mapboxgl.MapLayerMouseEvent) => {
        map.getCanvas().style.cursor = "pointer";
        const f = e.features?.[0];
        const id = f?.id;
        if (id == null) return;
        if (hoverIdRef.current != null && hoverIdRef.current !== id) {
          try {
            map.setFeatureState({ source: RIVERS_SOURCE, id: hoverIdRef.current as number }, { hover: false });
          } catch {
            /* ignore */
          }
        }
        hoverIdRef.current = id;
        try {
          map.setFeatureState({ source: RIVERS_SOURCE, id: id as number }, { hover: true });
        } catch {
          /* ignore */
        }
      });

      map.on("mouseleave", UNCLUSTERED_LAYER, () => {
        map.getCanvas().style.cursor = "";
        if (hoverIdRef.current != null) {
          try {
            map.setFeatureState({ source: RIVERS_SOURCE, id: hoverIdRef.current as number }, { hover: false });
          } catch {
            /* ignore */
          }
        }
        hoverIdRef.current = null;
      });

      map.on("mouseenter", ACCESS_LAYER, () => {
        map.getCanvas().style.cursor = "pointer";
      });
      map.on("mouseleave", ACCESS_LAYER, () => {
        map.getCanvas().style.cursor = "";
      });
      map.on("click", ACCESS_LAYER, (e: mapboxgl.MapLayerMouseEvent) => {
        const feature = e.features?.[0];
        if (!feature || !feature.geometry || feature.geometry.type !== "Point") return;
        const coords = [...feature.geometry.coordinates] as [number, number];
        const props = (feature.properties ?? {}) as Record<string, unknown>;
        const name =
          String(props.NAME ?? props.Name ?? props.name ?? "Fishing Access Site");
        new mapboxgl.Popup({ closeButton: false, closeOnClick: true, offset: 10 })
          .setLngLat(coords)
          .setHTML(`<div style="font-size:12px;font-weight:600;color:#0f172a;">${name}</div>`)
          .addTo(map);
      });

      map.on("mouseenter", ACTIVE_STATIONS_LAYER, () => {
        map.getCanvas().style.cursor = "pointer";
      });
      map.on("mouseleave", ACTIVE_STATIONS_LAYER, () => {
        map.getCanvas().style.cursor = "";
        stationHoverPopup.remove();
      });
      map.on("mousemove", ACTIVE_STATIONS_LAYER, (e: mapboxgl.MapLayerMouseEvent) => {
        const feature = e.features?.[0];
        if (!feature || !feature.geometry || feature.geometry.type !== "Point") return;
        const coords = [...feature.geometry.coordinates] as [number, number];
        const props = (feature.properties ?? {}) as Record<string, unknown>;
        stationHoverPopup
          .setLngLat(coords)
          .setHTML(getStationTooltipHtml(props))
          .addTo(map);
      });
      map.on("click", ACTIVE_STATIONS_LAYER, (e: mapboxgl.MapLayerMouseEvent) => {
        const feature = e.features?.[0];
        if (!feature || !feature.geometry || feature.geometry.type !== "Point") return;
        const coords = [...feature.geometry.coordinates] as [number, number];
        const props = (feature.properties ?? {}) as Record<string, unknown>;
        const stationName = String(props.station_name ?? props.site_no ?? "USGS Station");
        const siteNo = String(props.site_no ?? "").trim();
        const rolesText = String(props.roles_csv ?? "").trim();
        const relatedRiverNames = String(props.related_river_names_csv ?? "").trim();
        const sourceRoles = String(props.selected_source_roles ?? "").trim();
        const selectedName = String(props.selected_river_name ?? "").trim();
        const sourceText =
          sourceRoles && selectedName
            ? `Used for ${selectedName}: ${sourceRoles}`
            : sourceRoles
              ? `Used as: ${sourceRoles}`
              : "";

        stationHoverPopup.remove();

        new mapboxgl.Popup({ closeButton: false, closeOnClick: true, offset: 10 })
          .setLngLat(coords)
          .setHTML(
            `<div style="min-width:184px;font-size:12px;color:#0f172a;line-height:1.4;">
              <div style="font-weight:700;">${escapeHtml(stationName)}</div>
              <div style="font-size:11px;color:#334155;">${escapeHtml(siteNo || "USGS station")}</div>
              <div style="margin-top:4px;font-size:11px;color:#334155;">${escapeHtml(rolesText || "role metadata pending")}</div>
              ${relatedRiverNames ? `<div style="margin-top:2px;font-size:11px;color:#475569;">${escapeHtml(relatedRiverNames)}</div>` : ""}
              ${sourceText ? `<div style="margin-top:5px;font-size:11px;color:#1e293b;font-weight:600;">${escapeHtml(sourceText)}</div>` : ""}
            </div>`
          )
          .addTo(map);
      });
    }

    return () => {
      stationHoverPopup.remove();
      mapRef.current?.remove();
      mapRef.current = null;
      setMapReady(false);
      lastFlownRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapContainerRef.current) return;

    const safeResize = () => {
      if (mapRef.current !== map) return;
      if ((map as any)?._removed) return;
      const container = map.getContainer?.();
      if (!container || !container.isConnected) return;
      try {
        map.resize();
      } catch {
        // Ignore resize calls during map teardown.
      }
    };

    const handleResize = () => safeResize();
    window.addEventListener("resize", handleResize);

    const resizeObserver = new ResizeObserver(() => safeResize());
    resizeObserver.observe(mapContainerRef.current);

    return () => {
      window.removeEventListener("resize", handleResize);
      resizeObserver.disconnect();
    };
  }, [mapReady]);

  const riversKey = rivers.map((r) => r.river_id).join(",");
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapReady) return;
    if (typeof map.isStyleLoaded === "function" && !map.isStyleLoaded()) return;

    ensureRiversSource(map, rivers);
    ensureRiverPointLayers(map);
    syncRiverPointPresentation(map, selectedRiverId, true, effectiveLayerState.mri_score_coloring);

    if (!selectedRiverId) {
      const fc = riversToFeatureCollection(rivers);
      if (fc.features.length) {
        map.fitBounds(MONTANA_BOUNDS, {
          padding: { top: 112, right: rightPanelOpen ? 420 : 72, bottom: 118, left: 86 },
          duration: 0,
          pitch: 14,
          bearing: 0,
          maxZoom: 6.35,
        });
      }
    }
  }, [
    riversKey,
    mapReady,
    rivers,
    selectedRiverId,
    effectiveLayerState.mri_score_coloring,
    rightPanelOpen,
  ]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapReady) return;
    if (typeof map.isStyleLoaded === "function" && !map.isStyleLoaded()) return;
    syncRiverPointPresentation(
      map,
      selectedRiverId,
      true,
      effectiveLayerState.mri_score_coloring
    );
    syncSelectedRiverLine(
      map,
      riverLinesGeojson ?? selectedRiverGeojson,
      selectedRiverId,
      selectedRiverName,
      effectiveLayerState.mri_river_lines,
      effectiveLayerState.mri_selected_highlight,
      effectiveLayerState.mri_labels
    );

    if (!selectedRiverId) {
      lastFlownRef.current = null;
      lastFitSignatureRef.current = null;
      return;
    }

    const fitSignature = `${selectedRiverId}|${selectionSeq}|${rightPanelOpen ? 1 : 0}|${drawerState}`;
    if (lastFitSignatureRef.current === fitSignature) return;
    lastFitSignatureRef.current = fitSignature;
    lastFlownRef.current = selectedRiverId;

    const paddingBottom =
      drawerState === "expanded" ? 360 : drawerState === "mid" ? 220 : 120;
    const padding: mapboxgl.PaddingOptions = {
      top: 80,
      left: 40,
      right: rightPanelOpen ? 420 : 40,
      bottom: paddingBottom,
    };

    const focus: [number, number] | undefined =
      selectedRiver?.lat != null && selectedRiver?.lng != null
        ? [selectedRiver.lng, selectedRiver.lat]
        : RIVER_FOCUS_POINTS[selectedRiverId];

    const fullRiverBbox =
      selectedRiverBoundsFromGeojson(riverLinesGeojson, selectedRiverId) ??
      selectedRiverBoundsFromGeojson(selectedRiverGeojson, selectedRiverId) ??
      (selectedRiverGeojson ? geojsonBbox(selectedRiverGeojson) : null);

    if (fullRiverBbox && map.fitBounds) {
      map.fitBounds(
        [
          [fullRiverBbox[0], fullRiverBbox[1]],
          [fullRiverBbox[2], fullRiverBbox[3]],
        ],
        { padding, duration: 450, maxZoom: 11, essential: true }
      );
      return;
    }

    if (focus) {
      map.flyTo({
        center: focus,
        zoom: FLY_ZOOM,
        duration: 450,
        curve: FLY_CURVE,
        essential: true,
      });
    }
  }, [
    selectedRiverId,
    selectedRiverGeojson,
    riverLinesGeojson,
    selectedRiver,
    effectiveLayerState.mri_river_lines,
    effectiveLayerState.mri_selected_highlight,
    effectiveLayerState.mri_labels,
    effectiveLayerState.mri_score_coloring,
    rightPanelOpen,
    drawerState,
    selectionSeq,
    mapReady,
  ]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapReady) return;
    const nextStyle = MAPBOX_STYLES[basemap] ?? MAPBOX_STYLES.hybrid;
    if (currentStyleRef.current === nextStyle) return;
    currentStyleRef.current = nextStyle;
    map.setStyle(nextStyle);
  }, [basemap, mapReady]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapReady) return;
    if (typeof map.isStyleLoaded === "function" && !map.isStyleLoaded()) return;

    syncStatewideHydrologyLayer(map, effectiveLayerState.statewide_hydrology);
    syncFederalLandsLayer(map, effectiveLayerState.public_federal);
    syncStateLandsLayer(map, effectiveLayerState.public_state);
    syncFishingAccessLayer(map, effectiveLayerState.access_fishing_sites);
    syncActiveStationsLayer(map, effectiveLayerState.mri_active_stations, activeStationsGeojson, selectedRiver);
    syncHydrologyOverlays(
      map,
      effectiveLayerState.hydro_flow_magnitude,
      effectiveLayerState.hydro_change_indicator,
      effectiveLayerState.hydro_temp_stress
    );
    syncLabels(map, effectiveLayerState.mri_labels);
  }, [
    mapReady,
    effectiveLayerState.statewide_hydrology,
    effectiveLayerState.public_federal,
    effectiveLayerState.public_state,
    effectiveLayerState.access_fishing_sites,
    effectiveLayerState.mri_active_stations,
    effectiveLayerState.hydro_flow_magnitude,
    effectiveLayerState.hydro_change_indicator,
    effectiveLayerState.hydro_temp_stress,
    effectiveLayerState.mri_labels,
    activeStationsGeojson,
    selectedRiver?.river_id,
    selectedRiver?.flow_source_site_no,
    selectedRiver?.temp_source_site_no,
    selectedRiver?.river_name,
  ]);

  // Re-apply custom sources/layers after every Mapbox style change.
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    const handleStyleLoad = () => {
      setMapReady(true);
      syncRuntimeLayers(map);
      try {
        map.resize();
      } catch {
        /* ignore */
      }
    };

    map.on("style.load", handleStyleLoad);
    return () => {
      map.off("style.load", handleStyleLoad);
    };
  }, [syncRuntimeLayers]);

  return (
    <div
      id="map"
      ref={mapContainerRef}
      className={`absolute inset-0 h-full w-full min-h-0 [&_.mapboxgl-marker]:cursor-pointer ${className ?? ""}`.trim()}
      style={{ position: "absolute", inset: 0, height: "100%", width: "100%", minHeight: 320 }}
      aria-label="Montana river map"
    >
      {mapInitError && (
        <div className="pointer-events-none absolute inset-0 z-40 grid place-items-center bg-slate-100/85">
          <div className="pointer-events-auto rounded-xl bg-white px-6 py-5 text-center shadow-md">
            <div className="text-xl font-bold text-slate-900">Map unavailable</div>
            <div className="mt-1 text-sm text-slate-600">{mapInitError}</div>
          </div>
        </div>
      )}
      {mapReady && mapRef.current && <MapControls map={mapRef.current} />}
    </div>
  );
}
